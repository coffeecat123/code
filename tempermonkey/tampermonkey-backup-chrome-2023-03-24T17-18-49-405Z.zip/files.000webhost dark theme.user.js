// ==UserScript==
// @name         files.000webhost dark theme
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  dark theme
// @author       You
// @match        https://files.000webhost.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=000webhost.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    let a=`
<style>

::-webkit-scrollbar-corner {
    background:#181818;
}
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    border-radius: 10px;
    background-color: #303030;
}
::-webkit-scrollbar-thumb:hover {
    background: #6c6c6c;
}
::-webkit-scrollbar-thumb {
    background-color: #a1a1a1;
    border-radius: 10px;
}
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
    background:#181818;
}
::-webkit-scrollbar:hover{
    background:#181818;
}
.main, .row, .sidebar, angular-filemanager>div{
    background: #181818;
}
label.radio.bold.ng-binding {
    font-size: 20px;
    color: #eee;
}
div#code-editor {
    font-size: 30px;
    background: #1e1e1e;
    color:#eee;
}
form {
    background: #181818 !important;
}
.ace_gutter {
    background: #1e1e1e !important;
    color: #eee !important;
}
.ace-chrome .ace_gutter-active-line {
    background: #888 !important;
}
.ace-chrome .ace_cursor {
    color: #eee;
}
.ace-chrome .ace_string {
    color: #c5947c;
}
.ace-chrome .ace_marker-layer .ace_selection {
    background: #3b3d41;
}
.ace-chrome .ace_storage, .ace-chrome .ace_keyword, .ace-chrome .ace_meta.ace_tag {
    color: #679ad1;
}
.ace-chrome .ace_entity.ace_other.ace_attribute-name {
    color: #aadafa;
}
.ace-chrome .ace_keyword.ace_operator {
    color: #d3d3d3;
}
.ace-chrome .ace_support.ace_type, .ace-chrome .ace_support.ace_class.ace-chrome .ace_support.ace_other {
    color: #aadafa;
}
.ace-chrome .ace_support.ace_constant {
    color: #c5947c;
}
.ace-chrome .ace_constant.ace_numeric{
    color:#b4c7a6;
}
.ace-chrome .ace_entity.ace_name.ace_function {
    color: #dadaae;
}
.ace-chrome .ace_variable{
    color: #d2bb85;
}
.ace-chrome .ace_xml-pe {
    color: #888;
}
.ace-chrome .ace_support.ace_function {
    color: #dcdcaf;
}
.list-group-item {
    background-color: #303030;
}
h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
    color: #eee;
}
.btn.btn-default {
    color: #eee;
    background-color: #303030;
}
a.upgrade-btn.upgrade-btn--white.text-bolt.flex.flex-align-center.ng-binding {
    display: none;
}
.table-files .selected {
    background: #703535;
}
.btn-danger, .navbar-inverse {
    background: #703535;
}
.top-action-meniu {
    background: #703535;
}
.modal .modal-header{
    background: #703535;
}

</style>
`;
	let q = trustedTypes.createPolicy("forceInner", {
		createHTML: (to_escape) => to_escape
	});
    document.querySelector("head").insertAdjacentHTML('beforeend',q.createHTML(a));
})();