// ==UserScript==
// @name         柳吟線上測驗
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  ^_^
// @author       coffeecat
// @match        https://exam.ly-edu.com.tw/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=ly-edu.com.tw
// @grant        none
// ==/UserScript==


(function() {
    'use strict';
    let a=`
<style>

.wrap_style1 {
    background: #303030;
    color: #eee;
}
.exam .container_radio .radiomark:after {
    background: #00e4ff;
}
body {
    background: #181818;
    color:#eee;
}
.font_size li a.current {
    color: #00e4ff;
}
.topic_num_wrap {
    color: #888;
}
a {
    color: #888;
}
header.active , header{
    background: #888 !important;
}
.top_mbr_nav a{
    color:#000;
}
input {
    background: #505050;
    color: #eee;
}
button>ul {
    background: #181818;
    color: #eee;
}
.accordion-body {
    background: #242424;
    color: #999 !important;
}
.color01 {
    color: #323bf3;
}
.accordion-button {
    background: #242424 !important;
    color: #b8b8b8 !important;
}
.topic_solving_txt h2,.modal-body h2,#bulletin h2,font {
    color: #7b7bff;
}
.modal-content {
    background: #303030;
}
.modal-body {
    color: #aaa;
}
.bulletin_list li a {
    color: #ddd;
}
input:-webkit-autofill, input:-webkit-autofill:hover, input:-webkit-autofill:focus, textarea:-webkit-autofill, textarea:-webkit-autofill:hover, textarea:-webkit-autofill:focus, select:-webkit-autofill, select:-webkit-autofill:hover, select:-webkit-autofill:focus {
    -webkit-text-fill-color: #eee;
}

</style>
`;
	let q = trustedTypes.createPolicy("forceInner", {
		createHTML: (to_escape) => to_escape
	});
    document.querySelector("head").insertAdjacentHTML('beforeend',q.createHTML(a));
    var x=document.querySelector("#ctl00_ContentPlaceHolder1_txtQNum").value,y;
    setInterval(()=>{
        y=document.querySelector("#ctl00_ContentPlaceHolder1_txtQNum").value;
        if(x!=y){
            x=y;
            document.querySelector(".container-fluid").scrollIntoView({block:'start',behavior:'smooth'});
        }
    },100);
})();