// ==UserScript==
// @name         zh.wikipedia dark theme
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://zh.wikipedia.org/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    let a=`
<style>

body,#mw-page-base,.mw-body,.parsoid-body,.vector-menu-tabs-legacy .selected{
    background: #242424;
    color:#eee;
}
h1, h2, h3, h4, h5, h6,.vector-menu-tabs-legacy .selected a, .vector-menu-tabs-legacy .selected a:visited{
    color:#eee;
}
#mw-head li{
    background-image: linear-gradient(to top,#77c1f6 0,#28292a 1px,#000000 100%);
}
.mwe-math-element {
    filter: invert(1);
}
.toc {
    background: #303030;
}
span.tocnumber {
    color: #ccc;
}
a{
    color:#00d4ff;
}
.vector-menu-tabs-legacy li a{
    color:#346fff;
}
#p-logo,#sliderCollapseLogo{
    filter: invert(1);
}
#mw-panel .vector-menu-content-list>li>a{
    color:#67c0ff;
}
button.mw-interlanguage-selector.mw-ui-button {
    filter: invert(1);
}
table,#catlinks{
    background:#303030 !important;
}
table.vertical-navbox.nowraplinks.plainlist img{
    filter:invert(1);
}
.tipsy-inner{
    background:#505050;
    color:#eee;
}
.mwe-popups-container{
    background:#505050 !important;
}
.mwe-popups-extract>p{
    color:#ddd;
}
.mwe-popups .mwe-popups-extract[dir='ltr']:after{
    background-image: linear-gradient(to right,rgba(255,255,255,0),#505050 50%);
}
.toctogglelabel{
    color:#008fff;
}
.ilh-page a.new{
    color:#00d300;
}
a.new{
    color:#f00;
}
.rt-tooltip,.rt-tooltipTail,.rt-tooltipTail:after{
    background:#505050;
    color:#ddd;
}
.mw-parser-output a.extiw, .mw-parser-output a.external{
    color:#ffdb07
}
.vector-user-menu-legacy #pt-anonuserpage, .vector-user-menu-legacy #pt-tmpuserpage{
    color:#eee;
}
input#searchInput {
    color: #eee;
    background: #303030;
}
.navbox th, .navbox-title{
    background: #9191b4;
}
.mw-footer li{
    color:#eee;
}
div#content {
    background: #181818;
}
img.mwe-popups-thumbnail{
    outline: 1px solid rgba(255,255,255,0.1) !important;
}
.vector-menu-portal .vector-menu-heading{
    background-image: linear-gradient(to right,rgba(100,100,100,0) 0,rgb(100,100,100) 33%,rgb(100,100,100) 66%,rgba(100,100,100,0) 100%);
    color: #ddd;
}
.vector-menu-dropdown .vector-menu-heading{
    color:#ccc;
}
#p-personal .vector-menu-content li:not([id=pt-anonuserpage]){
    background-image: none;
}
.vertical-navbox.nowraplinks th{
    background: #8484bc;
    color:#4c4c4c;
}
.thumbinner {
    background-color: #303030 !important;
}
.mw-mmv-post-image,.mw-mmv-image-metadata {
    background: #181818;
    border-top: 1px solid #757575;
    color: #eee;
}
.mw-mmv-image-desc,.mw-mmv-credit{
    color:#ccc;
}
div#content p,div#content li {
    color: #eee !important;
}
.navbox-even {
    background:#404040 !important;
}
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    border-radius: 10px;
    background-color: #303030;
}
::-webkit-scrollbar-thumb:hover {
    background: #6c6c6c;
}
::-webkit-scrollbar-thumb {
    background-color: #a1a1a1;
    border-radius: 10px;
}
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}
::-webkit-resizer {
    background: #828282;
    outline: 2px solid #b6b6b6;
}

</style>
`;
	let q = trustedTypes.createPolicy("forceInner", {
		createHTML: (to_escape) => to_escape
	});
    document.querySelector("head").insertAdjacentHTML('beforeend',q.createHTML(a));
})();