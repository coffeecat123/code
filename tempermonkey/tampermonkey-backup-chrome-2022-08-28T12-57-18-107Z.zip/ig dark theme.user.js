// ==UserScript==
// @name         ig dark theme
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  ^_^
// @author       coffeecat
// @match        https://www.instagram.com/*
// @icon         
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    let a=`
<style>

svg {
    fill: #eee;
    color: #eee;
}
body._a3wf {
    color: #27fdc4;
}
._aa4c{
    --ig-secondary-button: 230,230,230 !important;
}
._ae65 {
    --ig-secondary-button: 230,230,230;
    --ig-banner-background: 50,50,50;
    --post-separator: 100,100,100;
    --ig-elevated-separator: 100,100,100;
    --ig-primary-background: 24,24,24;
    --ig-primary-button: 200, 130, 255;
    --ig-primary-text: 200,200,200;
    --ig-highlight-background: 50,50,50;
    --ig-secondary-background: 24,24,24;
    --ig-elevated-background: 0,0,0;
    --ig-link: 0, 150, 200;
}
.f0dnt3l3 {
    --ig-elevated-background:0,0,0;
    --ig-elevated-separator: 100,100,100;
    --ig-primary-text: 200,200,200;
}
._aeap._aeaq button._abl- svg._ab6- {
    fill: #000;
}
._aaqh{
    background:#eee;
}
._9zli {
    filter: invert(1);
}
._aatk._aatl._aatm {
    background-color: rgb(20,20,20);
}
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    border-radius: 10px;
    background-color: #303030;
}
::-webkit-scrollbar-thumb:hover {
    background: #6c6c6c;
}
::-webkit-scrollbar-thumb {
    background-color: #a1a1a1;
    border-radius: 10px;
}
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}
::-webkit-resizer {
    background: #828282;
    outline: 2px solid #b6b6b6;
}
#react-root main,#react-root footer{
    background:#181818;
}
.gr27e{
    background:#303030;
}
img[alt=Instagram]{
    filter:invert(1);
}
.gr27e{
    border: 1px solid #505050;
}
.b_nGN,.izU2O{
    color:#aaa;
}
.KPnG0,._2Lks6{
    color:#0bf;
}
input._2hvTZ.pexuQ.zyHYP,.i24fI{
    background: #181818;
    color:#eee;
}
._9GP1n{
    background:#505050;
}
.yWX7d._8A5w5{
    color:#aaa;
}
._2Lks6:hover, ._2Lks6:active, ._2Lks6:visited{
    color:#009bd1;
}
</style>
`;
	let q = trustedTypes.createPolicy("forceInner", {
		createHTML: (to_escape) => to_escape
	});
    document.querySelector("head").insertAdjacentHTML('beforeend',q.createHTML(a));
    document.querySelector(":root").style+=`
    --ig-secondary-button: 230,230,230;
    --ig-banner-background: 50,50,50;
    --post-separator: 100,100,100;
    --ig-elevated-separator: 100,100,100;
    --ig-primary-background: 24,24,24;
    --ig-primary-button: 200, 130, 255;
    --ig-primary-text: 200,200,200;
    --ig-highlight-background: 50,50,50;
    --ig-secondary-background: 24,24,24;
    --ig-elevated-background: 0,0,0;
    --ig-separator: 100,100,100;
    --ig-link: 0, 150, 200;
    --ig-badge: 140, 160, 255;
    --ig-stroke: 100,100,100;
`;
})();