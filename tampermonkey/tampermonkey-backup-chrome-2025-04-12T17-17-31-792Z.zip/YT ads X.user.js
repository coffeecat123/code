// ==UserScript==
// @name         YT ads X
// @namespace    ???
// @version      1.0
// @description  no ads
// @author       coffeecat
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// @noframes
// ==/UserScript==

(function() {
    'use strict';

    const $=(s)=>document.querySelector(s);
    const $$=(s)=>[...document.querySelectorAll(s)];

    var cnt=0;
    start();
    function start(){
        cnt++;
        let last_cnt=cnt;
        console.log("YT ads X");
        let url=location.href;
        if(url=="https://www.youtube.com/"){
            setInterval(function q(){
                if(last_cnt!=cnt){
                    clearInterval(q);
                }
                clear("div.ytd-rich-grid-renderer>ytd-rich-item-renderer:has(ytd-ad-slot-renderer)");
            },100);
        }
        else if(url.includes("https://www.youtube.com/watch")){
            setInterval(function q(){
                if(last_cnt!=cnt){
                    clearInterval(q);
                }
                clear("div#header.ytd-engagement-panel-section-list-renderer>panel-ad-header-image-lockup-view-model"
                      ,"div.ytd-item-section-renderer>ytd-ad-slot-renderer"
                      ,"div#player-ads");
            },100);

            setInterval(function q(){
                if(last_cnt!=cnt){
                    clearInterval(q);
                }
                let dv=$("div#columns .ytd-player>*>div.video-ads.ytp-ad-module");
                if(dv && dv.innerHTML!==""){
                    let v=$("div#columns .ytd-player>* video");
                    v.currentTime=v.duration;
                    console.log("skip");
                }
            },1);
        }
        else if(url.includes("https://www.youtube.com/results")){
            setInterval(function q(){
                if(last_cnt!=cnt){
                    clearInterval(q);
                }
                clear("div.ytd-item-section-renderer>ytd-search-pyv-renderer:has(ytd-ad-slot-renderer)"
                      ,"div.ytd-item-section-renderer>ytd-ad-slot-renderer");
            },100);
        }
    }

    function onUrlChange(callback) {
        let currentUrl = location.href;

        const checkUrl = () => {
            if (location.href !== currentUrl) {
                currentUrl = location.href;
                callback();
            }
        };

        // 攔截 pushState/replaceState
        ['pushState', 'replaceState'].forEach((type) => {
            const original = history[type];
            history[type] = function () {
                original.apply(this, arguments);
                checkUrl();
            };
        });

        window.addEventListener('popstate', checkUrl);
        setInterval(checkUrl, 1000); // 避免漏判，保險機制
    }
    onUrlChange(() => {
        console.log("URL changed:", location.href);
        setTimeout(start, 100);
    });

    function clear(...cls){
        cls.forEach(selector => {
            $$(selector).forEach(el => {
                console.log("hide");
                el.remove();
            });
        });
    }
})();