// ==UserScript==
// @name         coffeecat
// @namespace    ???
// @version      1.0
// @description  ^_^
// @author       coffeecat
// @match        http*://*/*
// @icon         https://avatars.githubusercontent.com/u/89003006?v=4
// @grant        none
// @noframes
// ==/UserScript==

javascript:(function() {
    'use strict';

    if(document.querySelectorAll(".coffeecat").length>0)return;
    console.log("coffeecat");
    const username = 'coffeecat123';
    const repo = 'code';
    const path = 'javascript/cft';

    async function getHtmlFile() {
        try {
            const response = await fetch(`https://api.github.com/repos/${username}/${repo}/contents/${path}`);
            const files = await response.json();
            const htmlFilePath = files.find(file => file.name.endsWith('.html')).download_url;

            const data = await (await fetch(htmlFilePath)).text();
            const doc = new DOMParser().parseFromString(data, 'text/html');

            let _dv = Array.from(doc.querySelectorAll('A')).map(link => ({
                innerText: link.innerText,
                href: link.getAttribute('HREF'),
                path: htmlFilePath
            }));

            _dv.splice(0, 1);
            console.log(_dv);
            start(_dv);
        } catch (error) {
            console.error('Error fetching file list:', error);
        }
    }

    getHtmlFile();
    function start(_dv){
        /*--------------------------------------------*/
        /*--------------------------------------------*/
        var _aa=document.createElement("div");
        var _ab=0;
        var _clr=document.createElement("input");
        var _clr2=document.createElement("input");
        _aa.append("background:",_clr,_clr2,document.createElement("br"));
        var _fm=document.createElement("iframe");
        _fm.width=500;
        _fm.height=100;
        _fm.setAttribute("allowfullscreen","");
        _fm.frameBorder='0';
        _fm.src='';
        var _yt=document.createElement("input");
        _yt.type="text";
        _yt.placeholder='YT video link';
        _yt.style='font-size: 15px !important;border: 1px black solid;';
        _yt.onchange=()=>{
            let _a=_yt.value;
            if(_a.includes("https://www.youtube.com/watch?")){
                let _q=_a.split("watch?v=");
                _a=_q[0]+`embed/`+_q[1].split("&")[0];
            }
            _fm.src=_a;
        };
        let _bta=document.createElement("div");
        _dv.forEach(item => {
            let _bt = document.createElement("button");
            _bt.style = 'font-size: 15px !important; border: 1px black solid; height: 25px';
            _bt.textContent = item.innerText;
            _bt.onclick = () => {
                const tempLink = document.createElement('a');
                tempLink.href = item.href;
                tempLink.click();
            };
            _bta.append(_bt);
        });
        _bta.style='display: flex;flex-wrap: wrap;';
        _aa.append(_bta);

        _aa.className="coffeecat";
        _aa.style=`
    font-size: 30px;
    position: fixed;
    top: 0;
    left: 0;
    width: 500px;
    height: 300px;
    z-index: 123456789;
    display: none;
    color: var(--txt-color);
    background: rgb(0 0 0 / 80%);
	transition: all .3s linear;`;

        _aa.append(_yt,_fm);
        _clr.type="color";
        _clr.style="width: 40px;";
        _clr2.type="range";
        _clr2.style="display: inline-block;width: 200px;";
        _clr2.min=0;
        _clr2.max=255;
        _clr2.step=1;
        _clr2.value=255;
        let __aq="#fff";
        /*----cookie-------*/
        try{
            function getCookie(name) {
                var value = `; ${document.cookie}`;
                var parts = value.split(`; ${name}=`);
                if (parts.length === 2) return parts.pop().split(';').shift();
                return -1;
            }
            let _getbk=getCookie("coffeecat_bk");
            if(_getbk!=-1){
                _clr.value=_getbk.substr(0,7);
                _clr2.value=parseInt(_getbk.substr(7,2),16);
                _aa.style.background=_getbk;
                if((parseInt(_clr.value.substring(1,3),16)+parseInt(_clr.value.substring(3,5),16)+parseInt(_clr.value.substring(5,7),16))/3>128){
                    __aq="#000";
                }
            }
        }catch(e){
            void(0);
        }
        /*--------------------*/
        document.body.addEventListener("keydown",(k)=>{
            if(k.ctrlKey&&k.altKey&&k.key=='Backspace'){
                if(_ab){
                    _aa.style.display="none";
                }
                else{
                    _aa.style.display="block";
                }
                _ab^=1;
            }
        });
        let a=`
<style>

:root{
	--txt-color:${__aq};
}
.coffeecat button {
	margin: 2px;
	border: none !important;
	text-align: center;
	cursor: pointer;
    color: var(--txt-color);
	background: #8bc34a8a !important;
	position: relative;
	transition: all .3s linear;
}
.coffeecat button::before {
	content: "";
	width: 20%;
	height: 20%;
	box-sizing: border-box;
	border-top: 1px solid var(--txt-color);
	border-left: 1px solid var(--txt-color);
	position: absolute;
	top: 0;
	left: 0;
	transition: all .3s linear;
}
.coffeecat button::after {
	content: "";
	width: 20%;
	height: 20%;
	box-sizing: border-box;
	border-bottom: 1px solid var(--txt-color);
	border-right: 1px solid var(--txt-color);
	position: absolute;
	bottom: 0;
	right: 0;
	transition: all .3s linear;
}
.coffeecat button:hover::before, .coffeecat button:hover::after {
	width: 100%;
	height: 100%;
}

</style>
`;
        let q = trustedTypes.createPolicy("forceInner", {
            createHTML: (to_escape) => to_escape
        });
        document.querySelector("head").insertAdjacentHTML('beforeend',q.createHTML(a));
        var root = document.querySelector(':root');
        _clr.oninput=_clr2.oninput=()=>{
            let __a=_clr.value+Number(_clr2.value).toString(16).padStart("2","0");
            _aa.style.background=__a;
            try{
                document.cookie=`coffeecat_bk=${__a};`;
            }catch(e){
                void(0);
            }
            if((parseInt(_clr.value.substring(1,3),16)+parseInt(_clr.value.substring(3,5),16)+parseInt(_clr.value.substring(5,7),16))/3>128){
                root.style.cssText+='--txt-color: #000;';
            }
            else{
                root.style.cssText+='--txt-color: #fff;';
            }
        };
        document.body.insertBefore(_aa,document.body.firstChild);
    }
})();