// ==UserScript==
// @name         bilibili dark theme
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  ^_^
// @author       coffeecat
// @match        https://*.bilibili.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=www.bilibili.com
// @grant        none
// ==/UserScript==


(function() {
    'use strict';
    let a=`
<style>

::-webkit-scrollbar-corner {
    background:#181818;
}
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    border-radius: 10px;
    background-color: #303030;
}
::-webkit-scrollbar-thumb:hover {
    background: #6c6c6c;
}
::-webkit-scrollbar-thumb {
    background-color: #a1a1a1;
    border-radius: 10px;
}
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}
::-webkit-resizer {
    background: #828282;
    outline: 2px solid #b6b6b6;
}
div#app {
    background: #181818;
}
.n .n-inner,#page-index .col-1{
    background: #303030 !important;
    color: #eee;
}
.n .n-data .n-data-v{
    color: #ddd;
}
h3.section-title,.user-info .user-info-title .info-title[data-v-31d5659a],#page-index .col-2 .section .user-auth.no-auth .no-auth-title .goto-auth{
    color: #eee;
}
#page-index .col-2 .section{
    background: #303030;
}
#page-index .col-1 .section.empty:after,#page-index .channel .empty-state p,.sec-empty-hint{
    color: #aaa;
}
.section .more,.i-m-btn{
    color: #ccc !important;
}
textarea.be-textarea_inner,.list-create{
    background: #505050 !important;
    color: #eee !important;
}
.list-create .text{
    color: #eee;
}
.header-channel{
    box-shadow: 0 2px 4px rgb(255 255 255 / 8%);
}
div[style="background-color: rgb(244, 244, 244); color: rgb(117, 117, 117);"]{
    background: transparent !important;
    color: #0bb !important;
}
body,.main-container{
    background: var(--bg1);
}
.eplist_ep_list_wrapper__Sy5N8 {
    background: var(--bg3);
}
.RecommendItem_wrap__5sPoo .RecommendItem_right_wrap__DJpVw .RecommendItem_title__jBsvL,.numberListItem_title__LNXrS,.imageListItem_titleWrap__YTlLH{
    color: var(--text1);
}
.SectionSelector_SectionSelector__TZ_QZ .SectionSelector_expand__VjjPD {
    background: linear-gradient(270deg,var(--bg3) 46.21%,hsla(210,8%,95%,0));
}

</style>
`;
	let q = trustedTypes.createPolicy("forceInner", {
		createHTML: (to_escape) => to_escape
	});
    document.querySelector("head").insertAdjacentHTML('beforeend',q.createHTML(a));
    document.querySelector(":root").style=`
    --text1: #eee;
    --text2: #eee;
    --text3: #a8a8a8;
    --v_text2: #bbb;
    --bg1: #181818;
    --bg2: #333;
    --bg3: #333;
    --line_regular: #888;
    --bg1_float: #181818;
    --bg2_float: #666;
    --v_graph_bg_regular: #555;
    --graph_bg_regular: #282828;
    --graph_bg_thin: #333;
    --graph_bg_thick: #888;
    --v_brand_blue_thin: #cce1e7;
`;
})();