// ==UserScript==
// @name         YT ads X
// @namespace    ???
// @version      1.0
// @description  no ads
// @author       coffeecat
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// @noframes
// ==/UserScript==

(function() {
    'use strict';

    const $=(s)=>document.querySelector(s);
    const $$=(s)=>[...document.querySelectorAll(s)];
    let last_href=location.href;
    start(last_href);
    setInterval(()=>{
        if(last_href!=location.href){
            last_href=location.href;
            setTimeout(start(last_href),1000);
        }
    },1000);
    function start(url){
        console.log("YT ads X");
        //---------https://www.youtube.com/watch?v=--------
        if(url.includes("https://www.youtube.com/watch")){
            setInterval(function q(){
                if(!url.includes("https://www.youtube.com/watch")){
                    clearInterval(q);
                    return;
                }
                var cls=["div#header.ytd-engagement-panel-section-list-renderer>panel-ad-header-image-lockup-view-model"
                        ,"div.ytd-item-section-renderer>ytd-ad-slot-renderer"
                        ,"div#player-ads"];
                cls.forEach(selector => {
                    $$(selector).forEach(el => {
                        console.log("hide");
                        el.remove();
                    });
                });
                let dv=$("div#columns .ytd-player>*>div.video-ads.ytp-ad-module");
                if(dv && dv.innerHTML!==""){
                    let v=$("div#columns .ytd-player>* video");
                    v.currentTime=v.duration
                    console.log("skip");
                }
            },1);
        }
        //---------https://www.youtube.com/results---------
        else if(url.includes("https://www.youtube.com/results")){
            setInterval(function q(){
                if(!url.includes("https://www.youtube.com/results")){
                    clearInterval(q);
                    return;
                }
                var cls=["div.ytd-item-section-renderer>ytd-search-pyv-renderer:has(ytd-ad-slot-renderer)"
                        ,"div.ytd-item-section-renderer>ytd-ad-slot-renderer"];
                cls.forEach(selector => {
                    $$(selector).forEach(el => {
                        console.log("hide");
                        el.remove();
                    });
                });
            },1);
        }
        //---------https://www.youtube.com/----------------
        else if(url=="https://www.youtube.com/"){
            setInterval(function q(){
                if(url!="https://www.youtube.com/"){
                    clearInterval(q);
                    return;
                }
                var cls=["div.ytd-rich-grid-renderer>ytd-rich-item-renderer:has(ytd-ad-slot-renderer)"];
                cls.forEach(selector => {
                    $$(selector).forEach(el => {
                        console.log("hide");
                        el.remove();
                    });
                });
            },1);
        }
    };
})();