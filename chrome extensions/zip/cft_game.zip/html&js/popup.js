let fpg=document.querySelector("#fpg");

fpg.onclick=()=>{
    window.open("fpg.html","_blank");
};